############LANDIS OPTIMIZER!###################
##ZJROBBINS 2022###################
###Zacharyinthewoods@gmail.com
###Github @ZacharyRobbins
##NO WARRANTY OF USE/SUPPORT/LIABILTY/RESULTS####

### This program should do the follow. 
### 1) Automate LANDIS-II runs
### 2) Calculate a liklihood compared to a vector of data
### 3) Update parameters in text files 
### 4) Repeat. 
### This contains a:

### 1) A random brute force optimization

## This function random draws between predefined range
BF_draw<-function(H1,L1,H2,L2){
  Out1<-runif(1,H1,L1)
  Out2<-runif(1,H2,L2)
  return(c(Out1,Out2))
}
### Calculate normal log liklihood.
normalF <- function(parvec,x) { ### Calcluate normal Log likelihood (You may also want LogNormal logliklihood)
  # Log of likelihood of a normal distribution
  # parvec[1] - mean
  # parvec[2] - standard deviation
  mu_x<-parvec[[1]]
  sd<-as.numeric(parvec[2])
  # x - set of observations. Should be initialized before MLE
  sum (-log(sd * sqrt(2* pi) )-((x-mu_x)**2) / (2*sd**2))
}
### This rights the text for you in each folder. 
UpdateTextBF<-function(Log1,VOI){
  object<-readtext(Log1)
  Lineofintrest<-64
  draw<-BF_draw(VOI[1],VOI[2],VOI[3],VOI[4])
  line_rep<-as.character(paste("Hw","3", draw[1], "45", 0.8594, 
                               0.0287,0.25,draw[2],sep = "\t"))
  Bottom<-readLines(Log1, n =-(200))
  #print(Bottom)
  Bottom[Lineofintrest]<-line_rep
  fileConn<-file(Log1)
  writeLines(Bottom,fileConn)
  close(fileConn)
  Saveold<-c(draw[1],draw[2])
}

### The wrapper for the runs, iterates across 5 setups and runs random parameters in 
### the pre defined range. 

BruteForce<-function(Drive,samples,VOI,ObsData,waitit){
  DF<-NULL
  for(r in 1:samples){
    Save<-NULL
    #### update across the differnt runs
    for(i in 1:5){
    ### The original LANDIS-II file you want to change.
    txt<-paste0(Drive,"/hemlock one cell",i,
               "/ForCS_PH_machined.txt")  
    Saveold<-UpdateTextBF(txt,VOI)
    
    Save[i]<-Saveold[1]
    Save[5+i]<-Saveold[2]
    }
    ###Set up and run drives
    setwd(paste0(Drive,'hemlock one cell1/'))
    shell.exec("SimpleBatchFile.bat")
    print("1")
    setwd(paste0(Drive,'hemlock one cell2/'))
    shell.exec("SimpleBatchFile.bat")
    print("2")
    setwd(paste0(Drive,'hemlock one cell3/'))
    shell.exec("SimpleBatchFile.bat")
    print("3")
    setwd(paste0(Drive,'hemlock one cell4/'))
    shell.exec("SimpleBatchFile.bat")
    print("4")
    setwd(paste0(Drive,'hemlock one cell5/'))
    shell("SimpleBatchFile.bat", wait=TRUE)
    print("5")
    ### wait to ensure all runs are complete before moving to analysis. 
    print('wait')
    Sys.sleep(waitit)
    ### Load in landis data you are comparing to static data
    for(i in 1:5){
    EventLog1<-read.csv(
      paste0(Drive,'hemlock one cell',i,'/log_Summary.csv'))
    LL1<-normalF(EventLog1$ABio,ObsData$AboveGroundBiomass)
    row1<-data.frame(Run=r,ProposedLL=LL1,V1=Save[i],V2=Save[i+5])
    DF<-rbind(row1,DF)
    }
  }
  return(DF)
}


############### Set up 



Drive<-"C:/Users/zacha/Desktop/LANDIS-II_optimization_Wrapper/hemlock_BF/" ##  is the landis models are
ObsData<-read.csv(paste0("C:/Users/zacha/Desktop/LANDIS-II_optimization_Wrapper/",
                         "Sample_Cohort.csv")) ### Dataset we are comparing model runs to

DF<-NULL
waitit=10
###In practice
DF_out<-BruteForce(Drive, #Drive
           100, ## iterations
           c(5,15,0,1), ### This is the min and max of each value to assess. 
           ObsData, #Obs data.
           waitit ## How long to wait per round in seconds. If model fails increase
           ) 
