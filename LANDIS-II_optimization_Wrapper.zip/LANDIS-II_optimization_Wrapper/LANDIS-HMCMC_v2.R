############LANDIS OPTIMIZER!###################
##ZJROBBINS 2022###################
###Zacharyinthewoods@gmail.com
###Github @ZacharyRobbins
##NO WARRANTY OF USE/SUPPORT/LIABILTY/RESULTS####

### This program should do the follow. 
### 1) Automate LANDIS-II runs
### 2) Calculate a liklihood compared to a vector of data
### 3) Update parameters in text files 
### 4) Repeat. 


### It contains the program:  
### 2) A Hamiltonian MCMC optimization. 

##Libraries
library(readtext)

### This function compare the normal log likelidhood for two vectors

normalF <- function(parvec,x) { ### Calcluate normal Log likelihood (You may also want LogNormal logliklihood)
  # Log of likelihood of a normal distribution
  # parvec[1] - mean
  # parvec[2] - standard deviation
  mu_x<-parvec[[1]]
  sd<-as.numeric(parvec[2])
  # x - set of observations. Should be initialized before MLE
  sum (-log(sd * sqrt(2* pi) )-((x-mu_x)**2) / (2*sd**2))
}

### This function draws normals based on prior (works as a prior for MCMC)
Normal_draw<-function(Var1,sd1,Var2,sd2){
  Out1<-rnorm(1,Var1,sd1)
  Out2<-rnorm(1,Var2,sd2)
return(c(Out1,Out2))
}
### A hamiltonian acceptance function
Accept<-function(x,x_new){
  if(x_new>x){
    return(2)
  }else{
    rac<-runif(1,0,1)
    return(ifelse(rac<exp(x_new-x),2,1))
  }
}
### Not used in this setup
# Updatecsv<-function(Log1,VOI,sd1,sd2,sd3){
#     #Here we take the previous csv and do a hamiltonian draw to get new variables
#     draw<-Normal_draw(VOI[1],sd1,VOI[2],sd2,VOI[3],sd3)
#     draw<-round(draw)##make variables whole
#     Saveold<-c(Log1$Suppress_Category_0[c(2)],Log1$Suppress_Category_0[c(3)],Log1$Suppress_Category_0[c(4)])
#     # rebuild the .csv
#     Log1$Suppress_Category_0[c(2,6)]<-draw[1] 
#     Log1$Suppress_Category_0[c(3,7)]<-draw[2]
#     Log1$Suppress_Category_0[c(4,8)]<-draw[3]
#     #Write it back where it belongs  
#     write.csv(Log1,paste0(Drive,'Scrpple_Inputs/Suppression_InputMachine.csv'),
#             row.names = FALSE)
#     Saveold<-c(Saveold,draw[1],draw[2],draw[3])
#     return(Saveold)
#     
# }


UpdateText<-function(Log1,VOI,sd1,sd2){
  object<-readtext(Log1)
  Lineofintrest<-64
  draw<-Normal_draw(VOI[1],sd1,VOI[2],sd2)
  line_rep<-as.character(paste("Hw","3", draw[1], "45", 0.8594, 
                               0.0287,0.25,draw[2],sep = "\t"))
  Bottom<-readLines(Log1, n =-(200))
  #print(Bottom)
  Bottom[Lineofintrest]<-line_rep
  fileConn<-file(Log1)
  writeLines(Bottom,fileConn)
  close(fileConn)
  Saveold<-c(draw[1],draw[2])
}




MCMC<-function(Drive,Log1,samples,VOI,sd1,sd2,ObsData){
  for(r in 1:samples){
    print(VOI)
    ##############wrapper
    
    if(r==1){LL_old<--1e10} ## Check that your ll is not lower than this. 
    print(paste0("############RUN ",r," ##############"))
    ### The original LANDIS-II file you want to change.
    Saveold<-UpdateText(Log1,VOI,sd1,sd2)
    ##setdrive to location of file (This needs to be for shell.exec to work correctly)
    setwd(paste0(Drive))
    #start <- Sys.time() ### Timing the run 
    shell("SimpleBatchFile.bat",wait=T,intern=T) ### this will wait until the job is done. 
    #### intern =F to diagnose LANDIS-II in R
    #print(paste0(Sys.time()-start,"seconds"))
    ### Load in landis data you are comparing to static data
    EventLog1<-read.csv(
        paste0(Drive,'log_Summary.csv'))
    
    ### Calculate a normal log likelihood. 
    LL1<-normalF(EventLog1$ABio,ObsData$AboveGroundBiomass) ### So this is the vector we are comparing to the data, and the SD of the observation (Can be tuned or determined).
    print("Old")
    print(LL_old)
    print("New")
    print(LL1)
    Trigger<-Accept(LL_old,LL1) ### Accept or reject rule.
    ## Make a data frame of results
    row<-data.frame(Run=r,OldLL=LL_old,ProposedLL=LL1,Saveold[1],Saveold[2])
    DF<-rbind(row,DF)
    ### If the acceptance rule, keep new or old. 
    #VOI<-Saveold[1:2] ### if move is not accepted VOI stay the same
    if(Trigger==2){ ### if move is accepted
      VOI<-Saveold[1:2] ### Update variables to new variables
      print('Accept') ### Accept move
      LL_old<-LL1 ## hold new likelihood. 
    }else(print("Reject"))
      }
return(DF)
}
#### Implementation 

Drive<-"C:/Users/zacha/Desktop/LANDIS-II_optimization_Wrapper/hemlock one cell/" ## Where is the landis model
Log1<-paste("C:/Users/zacha/Desktop/LANDIS-II_optimization_Wrapper/hemlock one cell/",
            "ForCS_PH_machined.txt",sep="")
ObsData<-read.csv(paste0("C:/Users/zacha/Desktop/LANDIS-II_optimization_Wrapper/",
                        "Sample_Cohort.csv")) ### Dataset we are comparing model runs to

DF<-NULL
DF_out<-MCMC(Drive,#Drive where LANDIS IS
     Log1, # File to manipulate
     1000,# n samples to run 
     VOI=c(10,0.1), ## Initial values
     0.2,# Proposed sd of a normal distribution with mean initial value 1 
     0.01,# As above for value 2
     ObsData)# Observed data

(acceptanceRate<-length(unique(DF_out$OldLL))/length(DF_out$OldLL))

burn_in<-100 ## How many samples to disgard in the burn in 

print("Mortality Shape Param")

V1<-DF_out$Saveold.1.[burn_in:length(DF$DF_out$Saveold.1.)]
acf(V1, lag=500)
#95% Credible interval 
print(paste0("Median: ",median(V1),"95%: ",quantile(V1,0.025),' - ',quantile(V1,0.975)))

print("Growth Sape Param ")
V2<-DF_out$Saveold.2.[burn_in:length(DF$DF_out$Saveold.1.)]
acf(V2, lag=500)
print(paste0("Median: ",median(V2),"95%: ",quantile(V2,0.025),' - ',quantile(V2,0.975)))



